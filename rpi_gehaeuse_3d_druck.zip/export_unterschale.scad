// Export: Unterschale (Shell-Split Mode)
use </mnt/user-data/outputs/rpi_enclosure.scad>

unterschale();
