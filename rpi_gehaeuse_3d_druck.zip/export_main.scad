// Export: Hauptgehäuse
use </mnt/user-data/outputs/rpi_enclosure.scad>

// Export-Konfiguration für Hauptgehäuse
shell_split_mode = false;
show_front_panel = false;
show_back_panel = false;
show_main_body = true;

gehaeuse_hauptkoerper();
