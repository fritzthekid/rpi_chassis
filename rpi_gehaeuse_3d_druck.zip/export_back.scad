// Export: Rückpanel
use </mnt/user-data/outputs/rpi_enclosure.scad>

rueckpanel();
